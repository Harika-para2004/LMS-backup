import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import LogImage from "../assets/img/log.svg";
import RegisterImage from "../assets/img/register.svg";
import "../App.css";

const SignInSignUp = () => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [formData, setFormData] = useState({
    empid: "",
    email: "",
    password: "",
    project: "",
    designation: "",
    joiningDate: "",
    role: "",
  });

  const navigate = useNavigate();

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleRoleChange = (role) => {
    setFormData({ ...formData, role });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const apiUrl = isSignUp
      ? "http://localhost:5001/api/auth/signup"
      : "http://localhost:5001/api/auth/signin";

    try {
      const response = await axios.post(apiUrl, formData);
      alert(response.data.message);

      if (response.status === 200 || response.status === 201) {
        const userDataResponse = await axios.get(`http://localhost:5001/api/auth/user/${response.data.userId}`);
        const userData = userDataResponse.data;

        localStorage.setItem("userData", JSON.stringify(userData));

        if (userData.role === "employee") {
          navigate(`/home`, { state: { userData } });
        } else if (userData.role === "manager") {
          navigate(`/leaverequests`);
        }
        else if (userData.role === "admin") {
          navigate(`/admin`);
        }
      }
    } catch (error) {
      alert(error.response?.data?.message || "Something went wrong");
    }
  };

  return (
    <div className={`container ${isSignUp ? "sign-up-mode" : ""}`}>
      <div className="forms-container">
        <div className="signin-signup">
          {!isSignUp ? (
            <form className="sign-in-form" onSubmit={handleSubmit}>
              <h2 className="title">Sign in</h2>
              <div className="input-field">
                <i className="fas fa-user"></i>
                <input
                  type="text"
                  name="email"
                  placeholder="Email"
                  onChange={handleInputChange}
                  value={formData.email}
                  required
                />
              </div>
              <div className="input-field">
                <i className="fas fa-lock"></i>
                <input
                  type="password"
                  name="password"
                  placeholder="Password"
                  onChange={handleInputChange}
                  value={formData.password}
                  required
                />
              </div>
              <input type="submit" value="Login" className="btn solid" />
            </form>
          ) : (
            <form className="sign-up-form" onSubmit={handleSubmit}>
              <h2 className="title">Sign up</h2>
              <div className="input-group">
                <div className="input-field">
                  <i className="fas fa-user"></i>
                  <input
                    type="text"
                    name="empid"
                    placeholder="EmployeeID"
                    onChange={handleInputChange}
                    value={formData.empid}
                    required
                  />
                </div>
                <div className="input-field">
                  <i className="fas fa-envelope"></i>
                  <input
                    type="email"
                    name="email"
                    placeholder="Email"
                    onChange={handleInputChange}
                    value={formData.email}
                    required
                  />
                </div>
              </div>
              <div className="input-group">
                <div className="input-field">
                  <i className="fas fa-lock"></i>
                  <input
                    type="password"
                    name="password"
                    placeholder="Password"
                    onChange={handleInputChange}
                    value={formData.password}
                    required
                  />
                </div>
                <div className="input-field">
                  <i className="fas fa-building"></i>
                  <input
                    type="text"
                    name="project"
                    placeholder="project"
                    onChange={handleInputChange}
                    value={formData.project}
                    required
                  />
                </div>
              </div>
              <div className="input-group">
                <div className="input-field">
                  <i className="fas fa-briefcase"></i>
                  <input
                    type="text"
                    name="designation"
                    placeholder="Designation"
                    onChange={handleInputChange}
                    value={formData.designation}
                    required
                  />
                </div>
                <div className="input-field">
                  <i className="fas fa-calendar"></i>
                  <input
                    type="date"
                    name="joiningDate"
                    onChange={handleInputChange}
                    value={formData.joiningDate}
                    required
                  />
                </div>
              </div>
              <div className="input-group">
                <label>
                  <input
                    type="radio"
                    name="role"
                    value="employee"
                    checked={formData.role === "employee"}
                    onChange={() => handleRoleChange("employee")}
                  />
                  Employee
                </label>
                <label>
                  <input
                    type="radio"
                    name="role"
                    value="manager"
                    checked={formData.role === "manager"}
                    onChange={() => handleRoleChange("manager")}
                  />
                  Manager
                </label>
                <label>
                  <input
                    type="radio"
                    name="role"
                    value="admin"
                    checked={formData.role === "admin"}
                    onChange={() => handleRoleChange("admin")}
                  />
                  Admin
                </label>
              </div>
              <input type="submit" className="btn" value="Sign up" />
            </form>
          )}
        </div>
      </div>
      <div className="panels-container">
        <div className="panel left-panel">
          <div className="content">
            <h3>Leave Management System</h3>
            <p>Don't Have An Account? Signup Here</p>
            <button className="btn transparent" onClick={() => setIsSignUp(true)}>
              Sign up
            </button>
          </div>
          <img src={LogImage} className="image" alt="Log" />
        </div>
        <div className="panel right-panel">
          <div className="content">
            <h3>Leave Management System</h3>
            <p>Already Have An Account?</p>
            <button className="btn transparent" onClick={() => setIsSignUp(false)}>
              Sign in
            </button>
          </div>
          <img src={RegisterImage} className="image" alt="Register" />
        </div>
      </div>
    </div>
  );
};

export default SignInSignUp;
