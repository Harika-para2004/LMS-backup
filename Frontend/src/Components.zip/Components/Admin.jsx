import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";

function AdminDashboard() {
  const [selectedCategory, setSelectedCategory] = useState("holiday-calendar");
  const [holidays, setHolidays] = useState([]);
  const [leaveHistory, setLeaveHistory] = useState([]);
  const [selectedLeave, setSelectedLeave] = useState(null);

  const [editingRow, setEditingRow] = useState(null);
  const [formData, setFormData] = useState({
    date: "",
    day: "",
    name: "",
    type: "",
  });
  const [error, setError] = useState(null);
  const [showAddForm, setShowAddForm] = useState(false); // State to control form visibility

  const fetchLeaveHistory = async () => {
    const excludeEmail = "jm@gmail.com"; // Replace with the email to exclude
    try {
      const response = await fetch("http://localhost:5001/leaverequests");
      if (response.ok) {
        const data = await response.json();
        const filteredData = data.filter((item) => item.email !== excludeEmail); // Filter out records with the given email
        setLeaveHistory(filteredData); // Update state with filtered data
      } else {
        console.error("Failed to fetch leave history");
      }
    } catch (error) {
      console.error("Error fetching leave history:", error);
    }
  };
  useEffect(() => {
    fetchLeaveHistory();
  }, []);
  useEffect(() => {
    const fetchHolidays = async () => {
      try {
        const response = await fetch("http://localhost:5001/holidays");
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const data = await response.json();
        setHolidays(data);
      } catch (error) {
        console.error("Error fetching holidays:", error);
        setError("Failed to fetch holidays. Please try again later.");
      }
    };

    fetchHolidays();
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleAddHoliday = async () => {
    if (!formData.date || !formData.day || !formData.name || !formData.type) {
      setError("All fields are required.");
      return;
    }

    try {
      const response = await fetch("http://localhost:5001/holidays", {
        method: "POST",
        body: JSON.stringify(formData),
        headers: {
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error("Failed to add holiday.");
      }

      const newHoliday = await response.json();
      setHolidays([...holidays, newHoliday]);
      setShowAddForm(false);
      setFormData({ date: "", day: "", name: "", type: "" });
      setError(null);
    } catch (error) {
      console.error("Error adding holiday:", error);
      setError("Failed to add holiday. Please try again later.");
    }
  };

  const handleApprove = async () => {
    if (selectedLeave) {
      const { selectedIndex, ...leave } = selectedLeave;
      const updatedLeave = {
        ...leave,
        availableLeaves: leave.availableLeaves - 1,
        usedLeaves: leave.usedLeaves + 1,
        status: leave.status.map((stat, index) =>
          index === selectedIndex && stat === "pending" ? "Approved" : stat
        ),
      };

      try {
        const response = await fetch(
          `http://localhost:5001/leaverequests/${leave._id}`,
          {
            method: "PUT",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify(updatedLeave),
          }
        );

        if (response.ok) {
          const updatedLeaveFromServer = await response.json();
          setLeaveHistory((prevHistory) =>
            prevHistory.map((item) =>
              item._id === updatedLeaveFromServer._id
                ? updatedLeaveFromServer
                : item
            )
          );
          setSelectedLeave(null);
          console.log(
            "Approved and updated in the database:",
            updatedLeaveFromServer
          );
        } else {
          console.error("Failed to update leave in the database");
        }
      } catch (error) {
        console.error("Error updating leave in the database:", error);
      }
    }
  };

  const handleRowClick = (leave, index) => {
    setSelectedLeave({ ...leave, selectedIndex: index });
  };

  const renderContent = () => {
    switch (selectedCategory) {
      case "holiday-calendar":
        return (
          <div>
            <h2>Holiday Calendar</h2>
            {error && <div className="error-message">{error}</div>}
            <button onClick={() => setShowAddForm(!showAddForm)}>
              {showAddForm ? "Close Add Form" : "Add New Holiday"}
            </button>
            {showAddForm && (
              <div className="add-form">
                <h3>Add New Holiday</h3>
                <input
                  type="text"
                  name="date"
                  placeholder="Date"
                  value={formData.date}
                  onChange={handleInputChange}
                />
                <input
                  type="text"
                  name="day"
                  placeholder="Day"
                  value={formData.day}
                  onChange={handleInputChange}
                />
                <input
                  type="text"
                  name="name"
                  placeholder="Holiday Name"
                  value={formData.name}
                  onChange={handleInputChange}
                />
                <input
                  type="text"
                  name="type"
                  placeholder="Holiday Type"
                  value={formData.type}
                  onChange={handleInputChange}
                />
                <button onClick={handleAddHoliday}>Add Holiday</button>
              </div>
            )}
            <table className="holiday-table">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Day</th>
                  <th>Name of Holiday</th>
                  <th>Holiday Type</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {holidays.map((holiday, index) => (
                  <tr key={holiday._id}>
                    {editingRow === index ? (
                      <>
                        <td>
                          <input
                            type="text"
                            name="date"
                            value={formData.date}
                            onChange={handleInputChange}
                          />
                        </td>
                        <td>
                          <input
                            type="text"
                            name="day"
                            value={formData.day}
                            onChange={handleInputChange}
                          />
                        </td>
                        <td>
                          <input
                            type="text"
                            name="name"
                            value={formData.name}
                            onChange={handleInputChange}
                          />
                        </td>
                        <td>
                          <input
                            type="text"
                            name="type"
                            value={formData.type}
                            onChange={handleInputChange}
                          />
                        </td>
                        <td>
                          <button onClick={() => handleSave(index)}>
                            Save
                          </button>
                        </td>
                      </>
                    ) : (
                      <>
                        <td>{holiday.date}</td>
                        <td>{holiday.day}</td>
                        <td>{holiday.name}</td>
                        <td>{holiday.type}</td>
                        <td>
                          <button onClick={() => handleEdit(index)}>
                            Edit
                          </button>
                        </td>
                      </>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );
      case "leavepolicy":
        return <div></div>;
      case "reports":
        return <div></div>;
      case "leaverequests":
        return (
          <div className="history-container">
            <h2>Leave Requests</h2>
            <table id="tb">
              <thead>
                <tr>
                  <th>Leave Type</th>
                  <th>From</th>
                  <th>To</th>
                  <th>Reason</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {leaveHistory.map((leave) =>
                  leave.startDate.map((startDate, index) => (
                    <tr
                      key={`${leave._id}-${index}`}
                      onClick={() => handleRowClick(leave, index)}
                    >
                      <td>{leave.leaveType}</td>
                      <td>{new Date(startDate).toLocaleDateString()}</td>
                      <td>
                        {new Date(leave.endDate[index]).toLocaleDateString()}
                      </td>
                      <td>{leave.reason[index]}</td>
                      <td>{leave.status[index]}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>

            {selectedLeave && (
              <div className="details-container">
                <h3>Leave Details</h3>
                <p>Employee Email: {selectedLeave.email}</p>
                <p>Leave Type: {selectedLeave.leaveType}</p>
                <p>
                  From:{" "}
                  {new Date(
                    selectedLeave.startDate[selectedLeave.selectedIndex]
                  ).toLocaleDateString()}
                </p>
                <p>
                  To:{" "}
                  {new Date(
                    selectedLeave.endDate[selectedLeave.selectedIndex]
                  ).toLocaleDateString()}
                </p>
                <p>
                  Reason: {selectedLeave.reason[selectedLeave.selectedIndex]}
                </p>
                <p>
                  Status: {selectedLeave.status[selectedLeave.selectedIndex]}
                </p>
                <p>Total Leaves: {selectedLeave.totalLeaves}</p>
                <p>Available Leaves: {selectedLeave.availableLeaves}</p>
                <p>Used Leaves: {selectedLeave.usedLeaves}</p>
                <div className="action-buttons">
                  <button onClick={handleApprove}>Approve</button>
                  <button onClick={() => setSelectedLeave(null)}>Reject</button>
                </div>
              </div>
            )}
          </div>
        );
      default:
        return <div>Select a category to get started!</div>;
    }
  };

  return (
    <div className="dashboard-container">
      <header className="header">
        <h1 className="title">Admin Dashboard</h1>
        <div className="welcome-message" style={{ margin: "auto" }}>
          Welcome, Admin
        </div>
      </header>
      <div className="content">
        <nav className="sidebar">
          <ul>
            <li>
              <Link
                to="#"
                onClick={() => setSelectedCategory("holiday-calendar")}
              >
                Holiday Calendar
              </Link>
            </li>
            <li>
              <Link to="#" onClick={() => setSelectedCategory("reports")}>
                Reports
              </Link>
            </li>
            <li>
              <Link to="#" onClick={() => setSelectedCategory("leavepolicy")}>
                Leave Policy Configuration
              </Link>
            </li>

            <li>
              <Link to="#" onClick={() => setSelectedCategory("leaverequests")}>
                Leave Requests{" "}
              </Link>
            </li>
          </ul>
        </nav>
        <main className="main-content">{renderContent()}</main>
      </div>
    </div>
  );
}

export default AdminDashboard;
