import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";

function LeaveRequests() {
  const [leaveHistory, setLeaveHistory] = useState([]);
  const [selectedLeave, setSelectedLeave] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState("dashboard");
  const [leaveData, setLeaveData] = useState([]);
  const [email, setEmail] = useState("");
  const [leavehistory, setLeavehistory] = useState([]);
  const [holidays, setHolidays] = useState([]);
  useEffect(() => {
    const fetchHolidays = async () => {
      try {
        const response = await fetch("http://localhost:5001/holidays");
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const data = await response.json();
        setHolidays(data); 
      } catch (error) {
        console.error("Error fetching holidays:", error);
        setError("Failed to fetch holidays.");
      }
    };
  
    fetchHolidays();
  }, []);
  const fetchLeavehistory = async () => {
    try {
      const response = await fetch(`http://localhost:5001/leave-history?email=${email}`);
      if (response.ok) {
        const data = await response.json();
        setLeavehistory(data);
      } else {
        console.error("Failed to fetch leave history");
      }
    } catch (error) {
      console.error("Error fetching leave history:", error);
    }
  };

  useEffect(() => {
    if (selectedCategory === "history") {
      fetchLeavehistory();
    }
  }, [selectedCategory]);
  const [formData, setFormData] = useState({
    leaveType: "",
    applyDate:"",
    startDate: "",
    endDate: "",
    reason: "",
  });
  const fetchLeaveHistory = async () => {
    const excludeEmail = "thomas@gmail.com"; // Replace with the email to exclude
    try {
      const response = await fetch("http://localhost:5001/leaverequests");
      if (response.ok) {
        const data = await response.json();
        const filteredData = data.filter((item) => item.email !== excludeEmail); // Filter out records with the given email
        setLeaveHistory(filteredData); // Update state with filtered data
      } else {
        console.error("Failed to fetch leave history");
      }
    } catch (error) {
      console.error("Error fetching leave history:", error);
    }
  };
  
  useEffect(() => {
    const storedUserData = JSON.parse(localStorage.getItem("userData"));
    if (storedUserData) {
     
      setEmail(storedUserData.email || "");
      
    }
  }, []);

  useEffect(() => {
    if (email) {
      const fetchLeaveData = async () => {
        try {
          const response = await fetch(`http://localhost:5001/leavesummary?email=${email}`);
          if (response.ok) {
            const data = await response.json();
            setLeaveData(data);
          } else {
            console.error("Failed to fetch leave data");
          }
        } catch (error) {
          console.error("Error fetching leave data:", error);
        }
      };
      fetchLeaveData();
    }
  }, [email]);
  
  
  useEffect(() => {
    fetchLeaveHistory();
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.leaveType || !formData.startDate || !formData.endDate || !formData.reason) {
      alert("All fields are required!");
      return;
    }

    try {
      const response = await fetch(`http://localhost:5001/leave?email=${email}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        const data = await response.json();
        alert(data.message);
        setFormData({ leaveType: "", startDate: "", endDate: "", reason: "" }); // Reset form
      } else {
        alert("Failed to submit leave application");
      }
    } catch (error) {
      console.error("Error:", error);
      alert("An error occurred. Please try again.");
    }
  };

  const handleApprove = async () => {
    if (selectedLeave) {
      const { selectedIndex, ...leave } = selectedLeave;
      const updatedLeave = {
        ...leave,
        availableLeaves: leave.availableLeaves - 1,
        usedLeaves: leave.usedLeaves + 1,
        status: leave.status.map((stat, index) =>
          index === selectedIndex && stat === "pending" ? "Approved" : stat
        ),
      };

      try {
        const response = await fetch(
          `http://localhost:5001/leaverequests/${leave._id}`,
          {
            method: "PUT",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify(updatedLeave),
          }
        );

        if (response.ok) {
          const updatedLeaveFromServer = await response.json();
          setLeaveHistory((prevHistory) =>
            prevHistory.map((item) =>
              item._id === updatedLeaveFromServer._id
                ? updatedLeaveFromServer
                : item
            )
          );
          setSelectedLeave(null);
          console.log("Approved and updated in the database:", updatedLeaveFromServer);
        } else {
          console.error("Failed to update leave in the database");
        }
      } catch (error) {
        console.error("Error updating leave in the database:", error);
      }
    }
  };

  const handleRowClick = (leave, index) => {
    setSelectedLeave({ ...leave, selectedIndex: index });
  };

  const renderContent = () => {
    switch (selectedCategory) {
      case "dashboard":
        return <div><table className="holiday-table">
        <thead>
          <tr>
            <th>Date</th>
            <th>Day</th>
            <th>Name of Holiday</th>
            <th>Holiday Type</th>
          </tr>
        </thead>
        <tbody>
          {holidays.length > 0 ? (
            holidays.map((holiday) => (
              <tr key={holiday._id}>
                <td>{holiday.date}</td>
                <td>{holiday.day}</td>
                <td>{holiday.name}</td>
                <td>{holiday.type}</td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="4">No holidays found.</td>
            </tr>
          )}
        </tbody>
      </table>
      

      <table className="leave-summary-table">
        <thead>
          <tr>
            <th>Leave Type</th>
            <th>Total</th>
            <th>Available</th>
            <th>Used</th>
          </tr>
        </thead>
        <tbody>
          {leaveData.map((leave, index) => (
            <tr key={index}>
              <td>{leave.leaveType}</td>
              <td>{leave.totalLeaves}</td>
              <td>{leave.availableLeaves}</td>
              <td>{leave.usedLeaves}</td>
            </tr>
          ))}
        </tbody>
      </table>
</div>;
      case "apply-leave":
        return (
          <div className="apply-leave-container">
            <h2>Apply Leave</h2>
            <form onSubmit={handleSubmit}>
              <label>
                Leave Type:
                <select name="leaveType" value={formData.leaveType} onChange={handleInputChange}>
  <option value="">Select Leave Type</option>
  <option value="sick">Sick/casual/Earned Leave</option>
  <option value="maternity">Maternity Leave</option>
  <option value="paternity">Paternity Leave</option>
  <option value="adoption">Adoption Leave</option>
  <option value="bereavement">Bereavement Leave</option>
  <option value="compensatory">Compensatory Off</option>
  <option value="lop">Loss of Pay (LOP)</option>
</select>

              </label>
              <br />
              <label>
  Apply Date:
  <input 
    type="date" 
    name="applyDate" 
    value={formData.applyDate} 
    onChange={handleInputChange} 
  />
</label><br/>

              <label>
                From Date:
                <input type="date" name="startDate" value={formData.startDate} onChange={handleInputChange} />
              </label>
              <br />
              <label>
                To Date:
                <input type="date" name="endDate" value={formData.endDate} onChange={handleInputChange} />
              </label>
              <br />
              <label>
                Reason:
                <textarea name="reason" value={formData.reason} onChange={handleInputChange} />
              </label>
              <br />
              <button type="submit" style={{backgroundColor:' #2c3e50',width:'100%'}}>Submit</button>
            </form>
          </div>);

      case "leaverequests":
        return (
          <div className="history-container">
            <h2>Leave Requests</h2>
            <table id="tb">
              <thead>
                <tr>
                  <th>Leave Type</th>
                  <th>Apply Date</th>
                  <th>From</th>
                  <th>To</th>
                  <th>Reason</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {leaveHistory.map((leave) =>
                  leave.startDate.map((startDate, index) => (
                    <tr
                      key={`${leave._id}-${index}`}
                      onClick={() => handleRowClick(leave, index)}
                    >
                      <td>{leave.leaveType}</td>
                      <td>{new Date(leave.applyDate).toLocaleDateString()}</td>

                      <td>{new Date(startDate).toLocaleDateString()}</td>
                      <td>
                        {new Date(leave.endDate[index]).toLocaleDateString()}
                      </td>
                      <td>{leave.reason[index]}</td>
                      <td>{leave.status[index]}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>

            {selectedLeave && (
              <div className="details-container">
                <h3>Leave Details</h3>
                <p>Employee Email: {selectedLeave.email}</p>
                <p>Leave Type: {selectedLeave.leaveType}</p>
                
                <p>
                  From:{" "}
                  {new Date(
                    selectedLeave.startDate[selectedLeave.selectedIndex]
                  ).toLocaleDateString()}
                </p>
                <p>
                  To:{" "}
                  {new Date(
                    selectedLeave.endDate[selectedLeave.selectedIndex]
                  ).toLocaleDateString()}
                </p>
                <p>Reason: {selectedLeave.reason[selectedLeave.selectedIndex]}</p>
                <p>Status: {selectedLeave.status[selectedLeave.selectedIndex]}</p>
                <p>Total Leaves: {selectedLeave.totalLeaves}</p>
                <p>Available Leaves: {selectedLeave.availableLeaves}</p>
                <p>Used Leaves: {selectedLeave.usedLeaves}</p>
                <div className="action-buttons">
                  <button onClick={handleApprove}>Approve</button>
                  <button onClick={() => setSelectedLeave(null)}>Reject</button>
                </div>
              </div>
            )}
          </div>
        );
        case "reports":
          return <div className="profile-content">Reports Content</div>;
        case "history":
          return  <div className="history-container">
          <h2>Leave History</h2>
          <table>
            <thead>
              <tr>
                <th>Leave Type</th>
                <th>Apply Date</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Reason</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {leavehistory.map((leave, index) => (
                <tr key={index}>
                  <td>{leave.leaveType}</td>
                  <td>{leave.applyDate}</td>
                  <td>{leave.startDate}</td>
                  <td>{leave.endDate}</td>
                  <td>{leave.reason}</td>
                  <td>{leave.status || "Pending"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>;
      default:
        return null;
    }
  };

  return (
    <div className="dashboard-container">
       <header className="header">
        <h1 className="title">Manager Dashboard</h1>
        <div className="welcome-message" style={{margin:'auto'}}>Welcome</div>
      </header>
      <div className="content">
        <nav className="sidebar">
          <ul>
         
            <li>
              <Link to="#" onClick={() => setSelectedCategory("dashboard")}>
                Dashboard
              </Link>
            </li>
            <li>
              <Link to="#" onClick={() => setSelectedCategory("leaverequests")}>
               Leave Requests
              </Link>
            </li>
            <li>
              <Link to="#" onClick={() => setSelectedCategory("reports")}>
               Reports
              </Link>
            </li>
            <li>
              <Link to="#" onClick={() => setSelectedCategory("apply-leave")}>
                Apply Leave
              </Link>
            </li>
        
            <li>
              <Link to="#" onClick={() => setSelectedCategory("history")}>
                History
              </Link>
            </li>
          </ul>
        </nav>
        <main className="main-content">{renderContent()}</main>
      </div>
    </div>
  );
}

export default LeaveRequests;
