import React, { useEffect, useState } from "react";
import "../App.css";
import LogImage from "../assets/so.jpeg";
import { Link } from "react-router-dom";

const App = () => {
  const [selectedCategory, setSelectedCategory] = useState("dashboard");
  const [userData, setUserData] = useState(null);
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [designation, setDesignation] = useState("");
  const [project, setProject] = useState("");
  const [holidays, setHolidays] = useState([]);
  const [leaveHistory, setLeaveHistory] = useState([]);
  const [leaveData, setLeaveData] = useState([]);
  const [name, setName] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [profileImage, setProfileImage] = useState(null);
  const [errors, setErrors] = useState({
    leaveType: "",
    from: "",
    to: "",
    reason: "",
    mismatch: "",
  });
  const [formData, setFormData] = useState({
    leaveType: "",
    applyDate: "",
    startDate: "",
    endDate: "",
    reason: "",
  });

  const updatePassword = async () => {
    const name = "mismatch";
    if (newPassword !== confirmPassword) {
      setErrors({
        ...errors,
        [name]: "Passwords do not match",
      });
      // alert("Passwords do not match");
      return;
    } else {
      setErrors({
        ...errors,
        [name]: "",
      });
    }

    try {
      const response = await fetch("http://localhost:5001/update-password", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email,
          newPassword,
        }),
      });

      const data = await response.json();
      if (response.ok) {
        alert("Password updated successfully!");
      } else {
        alert(data.message || "Failed to update password");
      }
    } catch (error) {
      console.error("Error updating password:", error);
      alert("An error occurred. Please try again.");
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
    if (value) {
      setErrors({
        ...errors,
        [name]: "",
      });
    }
  };

  const handleBlur = (e) => {
    const { name, value } = e.target;
    if (!value) {
      setErrors({
        ...errors,
        [name]: "Required field",
      });
    }
  };

  const getTodayDate = () => {
    const today = new Date();
    return today.toISOString().split("T")[0];
  };

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      console.log("Selected file:", file);
      // Update the state or form data as needed
    }
  };

  // here profile img ***********
  const handleProfileImageChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      setProfileImage(URL.createObjectURL(file)); // Display the selected image
    }
  };

  const handleLogout = () => {
    //localStorage.removeItem("userToken"); // Replace "userToken" with the key used for storing your authentication token
    //localStorage.removeItem("userData");

    window.location.href = "/login"; 
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (
      !formData.leaveType ||
      !formData.startDate ||
      !formData.endDate ||
      !formData.reason
    ) {
      alert("All fields are required!");
      return;
    }

    try {
      const response = await fetch(
        `http://localhost:5001/leave?email=${email}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(formData),
        }
      );

      if (response.ok) {
        const data = await response.json();
        alert(data.message);
        setFormData({ leaveType: "", startDate: "", endDate: "", reason: "" });
      } else {
        alert("Failed to submit leave application");
      }
    } catch (error) {
      console.error("Error:", error);
      alert("An error occurred. Please try again.");
    }
  };

  useEffect(() => {
    const storedUserData = JSON.parse(localStorage.getItem("userData"));
    if (storedUserData) {
      setUserData(storedUserData);
      setUsername(storedUserData.username || "");
      setEmail(storedUserData.email || "");
      setDesignation(storedUserData.designation || "");
      setProject(storedUserData.project || "");
      const extractedUsername = storedUserData.email.split("@")[0];
      setName(extractedUsername);
    }
  }, []);
  useEffect(() => {
    const fetchLeaveData = async () => {
      try {
        const response = await fetch(
          `http://localhost:5001/leavesummary?email=${email}`
        );
        if (response.ok) {
          const data = await response.json();
          console.log("Fetched Data:", data);
          setLeaveData(data);
        } else {
          console.error("Failed to fetch leave data");
        }
      } catch (error) {
        console.error("Error fetching leave data:", error);
      }
    };

    fetchLeaveData();
  }, [email]);

  console.log(leaveData);

  useEffect(() => {
    const fetchHolidays = async () => {
      try {
        const response = await fetch("http://localhost:5001/holidays");
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const data = await response.json();
        setHolidays(data);
      } catch (error) {
        console.error("Error fetching holidays:", error);
        setError("Failed to fetch holidays.");
      }
    };

    fetchHolidays();
  }, []);

  const fetchLeaveHistory = async () => {
    try {
      const response = await fetch(
        `http://localhost:5001/leave-history?email=${email}`
      );
      if (response.ok) {
        const data = await response.json();
        setLeaveHistory(data);
      } else {
        console.error("Failed to fetch leave history");
      }
    } catch (error) {
      console.error("Error fetching leave history:", error);
    }
  };

  useEffect(() => {
    if (selectedCategory === "history") {
      fetchLeaveHistory();
    }
  }, [selectedCategory]);

  const handleUpdateProfile = async () => {
    try {
      const response = await fetch(`http://localhost:5001/update-profile`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email,
          designation,
          project,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        alert(data.message || "Profile updated successfully!");
        setUserData((prevData) => ({
          ...prevData,
          email,
          designation,
          project,
        }));
        localStorage.setItem(
          "userData",
          JSON.stringify({
            ...userData,
            email,
            designation,
            project,
          })
        );
      } else {
        alert("Failed to update profile. Please try again.");
      }
    } catch (error) {
      console.error("Error updating profile:", error);
      alert("An error occurred. Please try again.");
    }
  };

  const renderContent = () => {
    switch (selectedCategory) {
      case "dashboard":
        return (
          <div className="dashboard">
            <div className="left-section">
              <table className="holiday-table">
                <thead>
                  <tr>
                    <th>Leave Type</th>
                    <th>Total</th>
                    <th>Available</th>
                    <th>Used</th>
                  </tr>
                </thead>
                <tbody>
                  {leaveData.map((leave, index) => (
                    <tr key={index}>
                      <td>{leave.leaveType}</td>
                      <td>{leave.totalLeaves}</td>
                      <td>{leave.availableLeaves}</td>
                      <td>{leave.usedLeaves}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="pie-chart-container">
                {/* Replace this with your pie chart component */}
                <p>Pie Chart Here</p>
              </div>
            </div>

            <table className="holiday-table">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Day</th>
                  <th>Name of Holiday</th>
                  <th>Holiday Type</th>
                </tr>
              </thead>
              <tbody>
                {holidays.length > 0 ? (
                  holidays.map((holiday) => (
                    <tr key={holiday._id}>
                      <td>{holiday.date}</td>
                      <td>{holiday.day}</td>
                      <td>{holiday.name}</td>
                      <td>{holiday.type}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="4">No holidays found.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        );
      case "apply-leave":
        return (
          <div className="apply-leave-container">
            <h2>Apply Leave</h2>
            <form onSubmit={handleSubmit}>
              <div style={{ display: "flex", gap: "15px", flexWrap: "wrap" }}>
                <label style={{ flex: "1 1 45%" }}>
                  Leave Type: <span className="req">*</span>{" "}
                  {errors.leaveType && (
                    <span className="req">{errors.leaveType}</span>
                  )}
                  <select
                    name="leaveType"
                    value={formData.leaveType}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                  >
                    <option value="">Select Leave Type</option>
                    <option value="sick">Sick/casual/Earned Leave</option>
                    <option value="maternity">Maternity Leave</option>
                    <option value="paternity">Paternity Leave</option>
                    <option value="adoption">Adoption Leave</option>
                    <option value="bereavement">Bereavement Leave</option>
                    <option value="compensatory">Compensatory Off</option>
                    <option value="lop">Loss of Pay (LOP)</option>
                  </select>
                </label>

                <label style={{ flex: "1 1 45%" }}>
                  Apply Date: <span className="req">*</span>{" "}
                  {errors.leaveType && (
                    <span className="req">{errors.leaveType}</span>
                  )}
                  <input
                    type="date"
                    name="applyDate"
                    value={formData.applyDate}
                    onChange={handleInputChange}
                  />
                </label>

                <label style={{ flex: "1 1 45%" }}>
                  From Date: <span className="req">*</span>{" "}
                  {errors.from && <span className="req">{errors.from}</span>}
                  <input
                    type="date"
                    name="startDate"
                    value={formData.startDate}
                    onChange={handleInputChange}
                    max={formData.endDate}
                    min={getTodayDate()}
                  />
                </label>

                <label style={{ flex: "1 1 45%" }}>
                  To Date: <span className="req">*</span>{" "}
                  {errors.to && <span className="req">{errors.to}</span>}
                  <input
                    type="date"
                    name="endDate"
                    value={formData.endDate}
                    onChange={handleInputChange}
                    min={formData.startDate ? formData.startDate : null}
                  />
                </label>

                <label style={{ flex: "1 1 45%" }}>
                  Reason: <span className="req">*</span>{" "}
                  {errors.reason && (
                    <span className="req">{errors.reason}</span>
                  )}
                  <textarea
                    name="reason"
                    value={formData.reason}
                    onChange={handleInputChange}
                  />
                </label>
              </div>

              {/* Attach Document Button */}
              <div>
                <div className="attach-button">
                  <label>
                    <input
                      type="file"
                      name="attachment"
                      onChange={handleFileChange}
                    />
                  </label>
                </div>
                <button type="submit">Submit</button>
              </div>
            </form>
          </div>
        );
      case "profile":
        return (
          <div className="profile-container">
            <div className="left-section">
              <div className="profile-picture">
                <img
                  src={profileImage || LogImage} // Display selected image or default
                  alt="Profile"
                  onClick={() =>
                    document.getElementById("profileImageInput").click()
                  }
                />
                <input
                  type="file"
                  id="profileImageInput"
                  style={{ display: "none" }}
                  accept="image/*"
                  onChange={handleProfileImageChange}
                />
              </div>
              <div className="user-details">
                <h2>Edit Profile</h2>
                <div className="input-row">
                  <label>Email:</label>
                  <input type="email" value={email} readOnly />
                </div>
                <div className="input-row">
                  <label>Designation:</label>
                  <input
                    type="text"
                    value={designation}
                    onChange={(e) => setDesignation(e.target.value)}
                  />
                </div>
                <div className="input-row">
                  <label>Project:</label>
                  <input
                    type="text"
                    value={project}
                    onChange={(e) => setProject(e.target.value)}
                  />
                </div>
                <div className="input-row">
                  <label>Joining Date:</label>
                  <input type="text" value="N/A" readOnly />
                </div>
                <div className="button-group">
                  <button>Update</button>
                  <button>Cancel</button>
                </div>
              </div>
            </div>
            <div className="right-section">
              <h3 id="h3">Update Password</h3>
              <div className="input-row">
                <label>New Password:</label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                />
              </div>
              <div className="input-row">
                <label>Confirm Password:</label>
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                />
              </div>
              <div className="button-group">
                <button>Update Password</button>
              </div>
            </div>
          </div>
        );

      case "history":
        return (
          <div className="history-container">
            <h2>Leave History </h2>
            <table>
              <thead>
                <tr>
                  <th>Leave Type</th>
                  <th>Apply Date</th>
                  <th>Start Date</th>
                  <th>End Date</th>
                  <th>Reason</th>
                  <th>Leave Status</th>
                </tr>
              </thead>
              <tbody>
                {leaveHistory.map((leave, index) => (
                  <tr key={index}>
                    <td>{leave.leaveType}</td>
                    <td>{leave.applyDate}</td>
                    <td>{leave.startDate}</td>
                    <td>{leave.endDate}</td>
                    <td>{leave.reason}</td>
                    <td>{leave.status || "Pending"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="dashboard-container">
      <header className="header">
        <h1 className="title">LMS</h1>
        <div className="welcome-message" style={{ margin: "auto" }}>
          Welcome {name}
        </div>
      </header>
      <div className="content">
        <nav className="sidebar">
          <ul>
            <li>
              <Link to="#" onClick={() => setSelectedCategory("dashboard")}>
                Dashboard
              </Link>
            </li>
            <li>
              <Link to="#" onClick={() => setSelectedCategory("apply-leave")}>
                Apply Leave
              </Link>
            </li>
            <li>
              <Link to="#" onClick={() => setSelectedCategory("profile")}>
                Profile
              </Link>
            </li>
            <li>
              <Link to="#" onClick={() => setSelectedCategory("history")}>
                History
              </Link>
            </li>
          </ul>
          <div className="logout">
            <Link to="#" onClick={handleLogout}>
              Logout
            </Link>
          </div>
        </nav>

        <div className="main-content">{renderContent()}</div>
      </div>
    </div>
  );
};

export default App;
